/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aula;

/**
 *
 * @author Linnuxz
 */
public class C1 {

    /**
     * @param args the command line arguments
     */
    public int soma(int a,int b){
        // TODO code application logic here
        return(a+b);}}



/*
public class C2 {   
   
    
   public int sub(int a,int b){
       // TODO code application logic here
       return(a-b);}}


public class C3 {
    public static void main(String args[])
    {C1 x=new C1();
    C2 y=new C2();
    
    System.out.println(x.soma(1,2));
    System.out.println(y.sub(2,1));
    
    }
    
}*/

