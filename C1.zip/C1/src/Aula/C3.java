/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aula;

import javax.swing.JOptionPane;
/**
 *
 * @author lab7aluno
 */
public class C3 {
    public static void main(String args[])
    {
    C1 x=new C1();
    C2 y=new C2();
    C4 w=new C4();
    C5 k=new C5();
    
   /* System.out.println(x.soma(1,2));
    System.out.println(y.sub(2,1));
    System.out.println(w.mult(2,1));
    System.out.println(k.div(2,1));*/
   
   JOptionPane.showMessageDialog(null, "O resultado: ");
   
    JOptionPane.showMessageDialog(null, "A soma é: \n"  + x.soma(1,2));
    JOptionPane.showMessageDialog(null,"A Subt é: \n" + y.sub(2,1));
    JOptionPane.showMessageDialog(null,"A Multiplicação é: \n" + w.mult(2,1));
    JOptionPane.showMessageDialog(null, "A divisão  é: \n" + k.div(2,1));
    
    }
    
    
}

